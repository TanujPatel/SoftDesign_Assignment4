package com.mycompany;

public class commonUtility {
    public static String getAppName(){
        return "My Company Project Beta Version";
    }
}
