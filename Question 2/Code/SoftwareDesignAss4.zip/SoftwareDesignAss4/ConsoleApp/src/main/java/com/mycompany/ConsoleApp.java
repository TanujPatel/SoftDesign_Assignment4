package com.mycompany;

public class ConsoleApp {
    public static void main(String[] args){
        String appName = commonUtility.getAppName();
        System.out.println("Welcome to " + appName);
    }
}
