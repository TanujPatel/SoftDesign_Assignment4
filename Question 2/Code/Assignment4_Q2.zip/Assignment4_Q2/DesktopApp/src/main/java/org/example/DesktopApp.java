package org.example;

import java.lang.*;
import java.util.*;
import java.io.*;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.EventQueue;
import java.awt.event.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class DesktopApp extends JFrame{

    private JLabel l1,l2,l3;
    private JTextField t1, t2, t3;
    private JButton j1, j2;
    private JTextArea detailTA;

    private ArrayList<CommonUtility> list;


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    DesktopApp frame = new DesktopApp();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public DesktopApp(){

        JFrame f = new JFrame("Cashier");

        l1 =new JLabel("UPC Code:");
        l1.setBounds(50, 50, 100,30);
        t1=new JTextField("0");
        t1.setBounds(50, 85,100, 30 );

        l2 =new JLabel("Product Name:");
        l2.setBounds(50, 120, 100,30);
        t2=new JTextField("Name");
        t2.setBounds(50, 155,100, 30 );

        l3 =new JLabel("Price:");
        l3.setBounds(50, 190, 100,30);
        t3=new JTextField("0");
        t3.setBounds(50, 225,100, 30 );

        detailTA = new JTextArea(100,200);
        detailTA.setBounds(50,50, 100,300);
        f.add(detailTA);
        detailTA.setVisible(false);

        j1 = new JButton("Add Product");
        j1.setBounds(50, 260, 150, 50);

        j2 = new JButton("Scan Product");
        j2.setBounds(210, 260, 150, 50);

        j1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                submitAction(e);
            }
        });
        j2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                searchAction(e);
            }
        });

        list = new ArrayList<CommonUtility>();
        readFile("products.txt");
        updateDetail();

        f.add(l1); f.add(t1);
        f.add(l2); f.add(t2);
        f.add(l3); f.add(t3);
        f.add(j1); f.add(j2);
        f.setSize(400, 400);
        f.setLayout(null);
        f.setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

    }

    private void submitAction(ActionEvent evt)
    {
        int pid=Integer.parseInt(t1.getText());
        String name = t2.getText();
        int price=Integer.parseInt(t3.getText());
        if(search(pid)==null)
        {
            list.add(new CommonUtility(pid,name,price));
            writeFile("products.txt");
            JOptionPane.showMessageDialog(this, "Product Added Successfully!");
            updateDetail();
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Product Already Exists!");
        }
    }

    private void searchAction(ActionEvent evt)
    {
        int pid = 0;
        String msg;

        pid = Integer.parseInt(t1.getText());
        CommonUtility prod = search(pid);

        if(prod!=null)
            msg = prod.toString();
        else
            msg = "Product Not Found!";

        JOptionPane.showMessageDialog(this,msg);
    }

    public void readFile(String filename) {
        try
        {
            String line = "";
            Scanner fileScan = new Scanner(new File(filename));
            while(fileScan.hasNextLine())
            {
                line = fileScan.nextLine();
                String[] token = line.split(",");
                list.add(new CommonUtility(Integer.parseInt(token[0]),token[1],
                        Integer.parseInt(token[2])));
            }
            fileScan.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

    private void updateDetail()
    {
        for(CommonUtility p: list)
        {
            detailTA.append(p.toString());
        }
    }

    public CommonUtility search(int pid){
        CommonUtility prod = null;
        for(CommonUtility p: list)
        {
            if(p.getID()==pid)
                prod=p;
        }
        return prod;
    }

    public void writeFile(String filename) {
        try
        {
            String line = "";
            FileWriter writer = new FileWriter(filename);
            for(CommonUtility p: list)
            {
                line = p.getID()+","+p.getName()+","+p.getPrice()+"\n";
                writer.write(line);
            }
            writer.close();
        } catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }

}
